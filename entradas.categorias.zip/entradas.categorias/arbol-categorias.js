jQuery(document).ready(function($) {
    // Mostrar solo las categorías de nivel 0 al principio
    $('.arbol-categorias > li').not('.nivel-0').hide();

    // Expandir y contraer el árbol al hacer clic en los iconos.
    $('.arbol-categorias').on('click', 'i.fa-folder, i.fa-folder-open', function() {
        var $elemento = $(this).parent('li');
        $elemento.children('ul').slideToggle();

        // Cambiar el icono según el estado de expansión
        if ($(this).hasClass('fa-folder')) {
            $(this).removeClass('fa-folder').addClass('fa-folder-open');
        } else {
            $(this).removeClass('fa-folder-open').addClass('fa-folder');
        }
    });

    // Mostrar las entradas al hacer clic en una categoría que las contiene
    $('.arbol-categorias').on('click', '.categoria-principal, .subcategoria', function() {
        var $elemento = $(this).parent('li');

        // Si la categoría ya está expandida y tiene entradas, no hacemos nada
        if ($elemento.hasClass('tiene-entradas') && $elemento.children('ul').length > 0) {
            return;
        }

        var categoria_id = $elemento.data('categoria-id');
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                'action': 'obtener_entradas_categoria',
                'categoria_id': categoria_id
            },
            success: function(response) {
                if (response) {
                    $elemento.addClass('tiene-entradas'); // Agregar la clase tiene-entradas
                    $elemento.children('ul').remove(); // Eliminar cualquier lista de entradas previamente cargada
                    $elemento.append('<ul class="entradas">' + response + '</ul>');
                }
            }
        });
    });
});
