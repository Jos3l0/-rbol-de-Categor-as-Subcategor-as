<?php
/*
Plugin Name: Árbol de Categorías y Entradas Sin Duplicados
Description: Muestra un árbol de categorías y entradas sin duplicar categorías o subcategorías.
Version: 1.2
Author: Portal Educativo de la DGE Gobierno de Mendoza
*/

$categorias_mostradas = array(); // Almacena las categorías ya mostradas

// Agregar scripts y estilos
function arbol_categorias_scripts() {
    wp_enqueue_script('arbol-categorias-js', plugin_dir_url(__FILE__) . 'arbol-categorias.js', array('jquery'), null, true);
    wp_enqueue_style('arbol-categorias-css', plugin_dir_url(__FILE__) . 'arbol-categorias.css');
}
add_action('wp_enqueue_scripts', 'arbol_categorias_scripts');

// Mostrar categorías con conteo de entradas
function mostrar_arbol_categorias() {
    global $categorias_mostradas;
    $categorias = get_categories(array('hide_empty' => false));

    if ($categorias) {
        echo '<div class="arbol-categorias-container">';
        echo '<ul class="arbol-categorias">';
        foreach ($categorias as $categoria) {
            if (!in_array($categoria->term_id, $categorias_mostradas)) {
                mostrar_categoria_y_subcategorias($categoria);
            }
        }
        echo '</ul>';
        echo '</div>';
    }
}

function mostrar_categoria_y_subcategorias($categoria) {
    global $categorias_mostradas;
    $subcategorias = get_categories(array('child_of' => $categoria->term_id, 'hide_empty' => false));
    $conteo_entradas = $categoria->count;

    // Marcar la categoría como mostrada
    if (!in_array($categoria->term_id, $categorias_mostradas)) {
        $categorias_mostradas[] = $categoria->term_id;

        echo '<li class="nivel-' . (count(get_ancestors($categoria->term_id, 'category'))) . '" data-categoria-id="' . $categoria->term_id . '">';
        echo '<i class="fa fa-folder"></i>';
        echo '<span class="categoria-principal">' . $categoria->name . ' (' . $conteo_entradas . ')</span>';

        if ($subcategorias) {
            echo '<ul>';
            foreach ($subcategorias as $subcategoria) {
                if (!in_array($subcategoria->term_id, $categorias_mostradas)) {
                    mostrar_categoria_y_subcategorias($subcategoria);
                }
            }
            echo '</ul>';
        }

        echo '</li>';
    }
}

// Registrar shortcode
function arbol_categorias_shortcode() {
    ob_start();
    mostrar_arbol_categorias();
    return ob_get_clean();
}
add_shortcode('arbol_categorias', 'arbol_categorias_shortcode');

// Manejar la solicitud AJAX para obtener entradas de una categoría
function obtener_entradas_categoria() {
    if (isset($_POST['categoria_id'])) {
        $categoria_id = intval($_POST['categoria_id']);
        $entradas = get_posts(array('category' => $categoria_id, 'numberposts' => -1));

        if ($entradas) {
            foreach ($entradas as $entrada) {
                echo '<li>' . $entrada->post_title . '</li>';
            }
        } else {
            echo '<li>No hay entradas en esta categoría.</li>';
        }
    }
    wp_die();
}
add_action('wp_ajax_obtener_entradas_categoria', 'obtener_entradas_categoria');
add_action('wp_ajax_nopriv_obtener_entradas_categoria', 'obtener_entradas_categoria');

?>
